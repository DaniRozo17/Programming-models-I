public interface Comando {
    void ejecutar();
}

public class EncenderTelevisorComando implements Comando {
    private Televisor televisor;

    public EncenderTelevisorComando(Televisor televisor) {
        this.televisor = televisor;
    }

    @Override
    public void ejecutar() {
        televisor.encender();
    }
}

public class ApagarTelevisorComando implements Comando {
    private Televisor televisor;

    public ApagarTelevisorComando(Televisor televisor) {
        this.televisor = televisor;
    }

    @Override
    public void ejecutar() {
        televisor.apagar();
    }
}

public class ReproducirDVDComando implements Comando {
    private ReproductorDVD reproductorDVD;

    public ReproducirDVDComando(ReproductorDVD reproductorDVD) {
        this.reproductorDVD = reproductorDVD;
    }

    @Override
    public void ejecutar() {
        reproductorDVD.reproducir();
    }
}

public class DetenerDVDComando implements Comando {
    private ReproductorDVD reproductorDVD;

    public DetenerDVDComando(ReproductorDVD reproductorDVD) {
        this.reproductorDVD = reproductorDVD;
    }

    @Override
    public void ejecutar() {
        reproductorDVD.detener();
    }
}

public class Televisor {
    public void encender() {
        System.out.println("El televisor está encendido");
    }
    public void apagar() {
        System.out.println("El televisor está apagado");
    }
}

public class ReproductorDVD {
    public void reproducir() {
        System.out.println("El DVD está reproduciendo");
    }

    public void detener() {
        System.out.println("El DVD está detenido");
    }
}
public class ControlRemoto {
    private Comando comando;

    public void setComando(Comando comando) {
        this.comando = comando;
    }

    public void presionarBoton() {
        comando.ejecutar();
    }
}

public class Main {
    public static void main(String[] args) {
        Televisor televisor = new Televisor();
        ReproductorDVD reproductorDVD = new ReproductorDVD();

        EncenderTelevisorComando encenderTelevisorComando = new EncenderTelevisorComando(televisor);
        ApagarTelevisorComando apagarTelevisorComando = new ApagarTelevisorComando(televisor);
        ReproducirDVDComando reproducirDVDComando = new ReproducirDVDComando(reproductorDVD);
        DetenerDVDComando detenerDVDComando = new DetenerDVDComando(reproductorDVD);

        ControlRemoto controlRemoto = new ControlRemoto();

        controlRemoto.setComando(encenderTelevisorComando);
        controlRemoto.presionarBoton(); // Salida: El televisor está encendido

        controlRemoto.setComando(apagarTelevisorComando);
        controlRemoto.presionarBoton(); // Salida: El televisor está apagado

        controlRemoto.setComando(reproducirDVDComando);
        controlRemoto.presionarBoton(); // Salida: El DVD está reproduciendo

        controlRemoto.setComando(detenerDVDComando);
        controlRemoto.presionarBoton(); // Salida: El DVD está detenido
    }
}



