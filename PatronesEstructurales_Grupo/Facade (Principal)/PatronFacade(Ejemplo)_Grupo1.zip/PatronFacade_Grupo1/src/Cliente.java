
public class Cliente {
    public static void main(String[] args){
        CineFacade cine = new CineFacade();
        cine.comprarEntrada("Avengers 5", 42, "1234-5678-9101-1121", 10.5);
    }
}
