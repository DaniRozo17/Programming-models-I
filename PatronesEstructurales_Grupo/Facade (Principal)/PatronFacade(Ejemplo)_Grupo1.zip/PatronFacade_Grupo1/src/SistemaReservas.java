
public class SistemaReservas {
    public void reservarAsiento(String pelicula, int asiento){
        System.out.println("Asiento " + asiento + " reservado para la pelicula " + pelicula);
    }
}
