
public class SistemaNotificaciones {
    public void enviarNotificacion(String mensaje){
        System.out.println("Notificación enviada: " + mensaje);
    }
}
