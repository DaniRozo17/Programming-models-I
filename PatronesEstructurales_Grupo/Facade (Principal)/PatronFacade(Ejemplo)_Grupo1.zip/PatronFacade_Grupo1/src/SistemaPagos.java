
public class SistemaPagos {
    public void procesarPago(String tarjeta, double monto){
        System.out.println("Pago de $" + monto + " procesado para la tarjeta " + tarjeta);
    }
}
